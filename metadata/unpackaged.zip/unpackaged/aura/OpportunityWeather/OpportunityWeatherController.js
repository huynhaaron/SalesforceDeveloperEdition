({
     doInit : function(component, event, helper) {
   		helper.getWeather(component);
     },
})