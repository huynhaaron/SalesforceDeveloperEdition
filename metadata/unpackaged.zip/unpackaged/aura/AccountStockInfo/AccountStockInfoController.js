({
     handleRecordLoaded : function(component, event, helper) {
   		helper.getStockInfo(component, event);
     },
})